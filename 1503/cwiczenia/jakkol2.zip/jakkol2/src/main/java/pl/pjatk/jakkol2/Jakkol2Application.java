package pl.pjatk.jakkol2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jakkol2Application {

	public static void main(String[] args) {
		SpringApplication.run(Jakkol2Application.class, args);
	}

}
