package pl.pjatk.jakkol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JakkolApplicationTests {

	@Test
	void contextLoads() {
	}

}
